package com.oxide.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.oxide.launcher.ui.navigation.OxideNavGraph
import com.oxide.launcher.ui.theme.OxideTheme
import com.oxide.launcher.viewmodel.OxideViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: OxideViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OxideTheme {
                val navController = rememberNavController()
                OxideNavGraph(navController = navController, viewModel = viewModel)
            }
        }
    }
}
