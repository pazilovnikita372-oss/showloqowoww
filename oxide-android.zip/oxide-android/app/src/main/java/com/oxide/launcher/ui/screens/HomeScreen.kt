package com.oxide.launcher.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.navigation.Screen
import com.oxide.launcher.ui.theme.*
import com.oxide.launcher.viewmodel.OxideViewModel

@Composable
fun HomeScreen(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    val uiState by viewModel.uiState.collectAsState()

    // Пульсирующая анимация логотипа
    val pulseAnim = rememberInfiniteTransition(label = "pulse")
    val scale by pulseAnim.animateFloat(
        initialValue = 1f,
        targetValue  = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logoScale"
    )
    val glowAlpha by pulseAnim.animateFloat(
        initialValue = 0.5f,
        targetValue  = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    OxideBackground {
        // Фоновые неоновые пятна
        Box(
            Modifier
                .size(320.dp)
                .align(Alignment.TopCenter)
                .offset(y = (-60).dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            OxideNeonPurple.copy(alpha = 0.18f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )
        Box(
            Modifier
                .size(200.dp)
                .align(Alignment.BottomStart)
                .offset(x = (-40).dp, y = 40.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(OxideNeonBlue.copy(0.12f), Color.Transparent)
                    ),
                    shape = CircleShape
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(0.5f))

            // ── OXIDE Logo ──
            Box(
                modifier  = Modifier.scale(scale),
                contentAlignment = Alignment.Center
            ) {
                // Glow ring
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    OxideNeonBlue.copy(alpha = glowAlpha * 0.4f),
                                    Color.Transparent
                                )
                            ),
                            shape = CircleShape
                        )
                )
                // Icon placeholder
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(OxideNeonPurple, OxideNeonBlue)
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Ø", fontSize = 38.sp, color = Color.White, fontWeight = FontWeight.Black)
                }
            }

            Spacer(Modifier.height(20.dp))

            // Title
            Text(
                text          = "ØXIDE",
                fontSize      = 46.sp,
                fontWeight    = FontWeight.Black,
                letterSpacing = 8.sp,
                color         = OxideTextPrimary
            )
            Text(
                text          = "GAME  •  LAUNCHER  •  MORE",
                fontSize      = 11.sp,
                letterSpacing = 3.sp,
                color         = OxideTextSecond
            )

            Spacer(Modifier.weight(1f))

            // Current profile chip
            val current = uiState.profiles.firstOrNull { it.isCurrent }
            if (current != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    OxideBadge("● ${current.name}", OxideNeonCyan)
                }
            }

            // ── 4 Action Cards ──
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                NeonActionCard(
                    icon        = Icons.Default.FolderOpen,
                    title       = "Перенести\nфайлы",
                    accentColor = OxideNeonBlue,
                    modifier    = Modifier.weight(1f),
                    onClick     = { navController.navigate(Screen.Files.route) }
                )
                NeonActionCard(
                    icon        = Icons.Default.PhoneAndroid,
                    title       = "Приложения",
                    accentColor = OxideNeonPurple,
                    modifier    = Modifier.weight(1f),
                    onClick     = { navController.navigate(Screen.Apps.route) }
                )
                NeonActionCard(
                    icon        = Icons.Default.CloudUpload,
                    title       = "Профили\nустройства",
                    accentColor = OxideNeonViolet,
                    modifier    = Modifier.weight(1f),
                    onClick     = { navController.navigate(Screen.Profiles.route) }
                )
                NeonActionCard(
                    icon        = Icons.Default.Settings,
                    title       = "Настройки",
                    accentColor = OxideNeonCyan,
                    modifier    = Modifier.weight(1f),
                    onClick     = { navController.navigate(Screen.Settings.route) }
                )
            }

            Spacer(Modifier.height(16.dp))
            NeonDivider()
            Spacer(Modifier.height(10.dp))

            Text(
                text          = "O X I D E  •  Т В О Й  М И Р  В  Т В О И Х  Р У К А Х",
                fontSize      = 9.sp,
                letterSpacing = 2.sp,
                color         = OxideTextSecond.copy(alpha = 0.6f),
                textAlign     = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
        }

        // Snackbar
        uiState.snackMessage?.let { msg ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                action = {
                    TextButton(onClick = { viewModel.clearSnack() }) { Text("OK") }
                }
            ) { Text(msg) }
        }
    }
}
