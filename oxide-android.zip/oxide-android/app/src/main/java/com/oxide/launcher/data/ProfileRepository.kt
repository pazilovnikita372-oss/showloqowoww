package com.oxide.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "oxide_prefs")

data class OxideProfile(
    val id: String,
    val name: String,
    val avatarIndex: Int   = 0,
    val themeColor: String = "blue",   // blue | purple | pink | cyan
    val uiScale: Float     = 1.0f,
    val wallpaperId: Int   = 0,
    val isCurrent: Boolean = false
)

class ProfileRepository(private val context: Context) {

    private val gson = Gson()
    private val KEY_PROFILES = stringPreferencesKey("profiles")

    val profiles: Flow<List<OxideProfile>> = context.dataStore.data.map { prefs ->
        val json = prefs[KEY_PROFILES] ?: defaultProfilesJson()
        val type = object : TypeToken<List<OxideProfile>>() {}.type
        gson.fromJson(json, type) ?: defaultProfiles()
    }

    suspend fun saveProfiles(list: List<OxideProfile>) {
        context.dataStore.edit { it[KEY_PROFILES] = gson.toJson(list) }
    }

    suspend fun addProfile(p: OxideProfile) {
        val current = getCurrentList()
        saveProfiles(current + p)
    }

    suspend fun deleteProfile(id: String) {
        val current = getCurrentList()
        saveProfiles(current.filter { it.id != id })
    }

    suspend fun setCurrentProfile(id: String) {
        val current = getCurrentList()
        saveProfiles(current.map { it.copy(isCurrent = it.id == id) })
    }

    suspend fun updateProfile(p: OxideProfile) {
        val current = getCurrentList()
        saveProfiles(current.map { if (it.id == p.id) p else it })
    }

    private fun defaultProfiles() = listOf(
        OxideProfile(id = "default", name = "Основной", isCurrent = true)
    )

    private fun defaultProfilesJson() = gson.toJson(defaultProfiles())

    private suspend fun getCurrentList(): List<OxideProfile> {
        var result: List<OxideProfile> = emptyList()
        context.dataStore.data.collect { prefs ->
            val json = prefs[KEY_PROFILES] ?: defaultProfilesJson()
            val type = object : TypeToken<List<OxideProfile>>() {}.type
            result = gson.fromJson(json, type) ?: defaultProfiles()
            return@collect
        }
        return result
    }
}
