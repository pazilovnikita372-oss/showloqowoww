package com.oxide.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.theme.*

@Composable
fun AboutScreen(navController: NavHostController) {
    OxideBackground {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            OxideTopBar(title = "О ПРИЛОЖЕНИИ", onBack = { navController.popBackStack() })
            NeonDivider()

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Logo
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .background(
                            Brush.linearGradient(listOf(OxideNeonPurple, OxideNeonBlue)),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Ø", fontSize = 48.sp, color = Color.White, fontWeight = FontWeight.Black)
                }

                Text(
                    "ØXIDE",
                    fontSize      = 40.sp,
                    fontWeight    = FontWeight.Black,
                    letterSpacing = 8.sp,
                    color         = OxideTextPrimary
                )
                Text(
                    "Версия 1.0.0  •  Build 1",
                    fontSize = 12.sp,
                    color    = OxideTextSecond
                )

                NeonDivider()

                // Feature list
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AboutFeature(Icons.Default.FolderOpen,       "Управление файлами")
                        AboutFeature(Icons.Default.Apps,              "Каталог приложений")
                        AboutFeature(Icons.Default.Person,            "Локальные профили устройства")
                        AboutFeature(Icons.Default.Palette,           "Скины и оформление")
                        AboutFeature(Icons.Default.Settings,          "Гибкие настройки")
                        AboutFeature(Icons.Default.Security,          "Без root и без слежки")
                    }
                }

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null,
                                tint = OxideNeonBlue, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Ограничения платформы", fontSize = 13.sp,
                                fontWeight = FontWeight.Bold, color = OxideTextPrimary)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Профили OXIDE — локальные настройки приложения. " +
                            "Приложение не изменяет IMEI, Android ID или системные параметры устройства. " +
                            "Root-доступ не запрашивается и не используется.",
                            fontSize   = 12.sp,
                            color      = OxideTextSecond,
                            lineHeight = 18.sp
                        )
                    }
                }

                Text(
                    "OXIDE • ТВОЙ МИР В ТВОИХ РУКАХ",
                    fontSize      = 10.sp,
                    letterSpacing = 2.sp,
                    color         = OxideTextSecond.copy(0.5f),
                    textAlign     = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun AboutFeature(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = OxideNeonBlue, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, fontSize = 13.sp, color = OxideTextPrimary)
    }
}
