package com.oxide.launcher.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oxide.launcher.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

data class InstalledApp(
    val name: String,
    val packageName: String,
    val isFavorite: Boolean = false
)

data class OxideUiState(
    val profiles: List<OxideProfile>   = emptyList(),
    val settings: OxideSettings        = OxideSettings(),
    val installedApps: List<InstalledApp> = emptyList(),
    val isLoading: Boolean             = false,
    val snackMessage: String?          = null
)

class OxideViewModel(app: Application) : AndroidViewModel(app) {

    private val profileRepo  = ProfileRepository(app)
    private val settingsRepo = SettingsRepository(app)

    private val _ui = MutableStateFlow(OxideUiState(isLoading = true))
    val uiState: StateFlow<OxideUiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            combine(profileRepo.profiles, settingsRepo.settings) { profiles, settings ->
                _ui.update { it.copy(profiles = profiles, settings = settings, isLoading = false) }
            }.collect()
        }
        loadInstalledApps()
    }

    // --- Profiles ---
    fun addProfile(name: String, theme: String = "blue") {
        viewModelScope.launch {
            profileRepo.addProfile(
                OxideProfile(id = UUID.randomUUID().toString(), name = name, themeColor = theme)
            )
            showSnack("Профиль «$name» создан")
        }
    }

    fun deleteProfile(id: String) {
        viewModelScope.launch {
            profileRepo.deleteProfile(id)
            showSnack("Профиль удалён")
        }
    }

    fun switchProfile(id: String) {
        viewModelScope.launch {
            profileRepo.setCurrentProfile(id)
            showSnack("Профиль переключён")
        }
    }

    fun updateProfile(p: OxideProfile) {
        viewModelScope.launch { profileRepo.updateProfile(p) }
    }

    // --- Settings ---
    fun updateSettings(s: OxideSettings) {
        viewModelScope.launch { settingsRepo.updateSettings(s) }
    }

    fun selectSkin(skinId: String) {
        viewModelScope.launch {
            settingsRepo.updateSettings(_ui.value.settings.copy(selectedSkinId = skinId))
            showSnack("Скин применён")
        }
    }

    // --- Apps ---
    private fun loadInstalledApps() {
        viewModelScope.launch {
            val pm = getApplication<Application>().packageManager
            val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
            val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .map { ri ->
                    InstalledApp(
                        name        = ri.loadLabel(pm).toString(),
                        packageName = ri.activityInfo.packageName
                    )
                }
                .sortedBy { it.name }
            _ui.update { it.copy(installedApps = apps) }
        }
    }

    fun launchApp(packageName: String, context: Context) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                context.startActivity(intent)
            } else {
                showSnack("Не удалось запустить приложение")
            }
        } catch (e: Exception) {
            showSnack("Ошибка запуска: ${e.message}")
        }
    }

    fun openAppInStore(packageName: String, context: Context) {
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("market://details?id=$packageName"))
        context.startActivity(intent)
    }

    // --- Snack ---
    fun showSnack(msg: String) {
        _ui.update { it.copy(snackMessage = msg) }
    }

    fun clearSnack() {
        _ui.update { it.copy(snackMessage = null) }
    }
}
