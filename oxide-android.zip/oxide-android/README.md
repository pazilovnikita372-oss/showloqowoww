# OXIDE — Virtual Space & Game Launcher

> **Game · Launcher · More** — неоновое виртуальное пространство для Android

---

## Реализованные экраны

| Экран | Путь навигации | Функции |
|-------|---------------|---------|
| **Главная** | `/home` | Пульсирующий логотип, 4 кнопки быстрого доступа, текущий профиль |
| **Файлы** | `/files` | Системный пикер файлов, импорт, экспорт ZIP, просмотр, поделиться, удаление с подтверждением |
| **Приложения** | `/apps` | Список установленных приложений, поиск, запуск, открыть в магазине |
| **Настройки** | `/settings` | Яркость неона, анимации, язык интерфейса |
| **Профили** | `/profiles` | Создание / редактирование / удаление / переключение локальных профилей |
| **Скины** | `/skins` | 8 встроенных скинов, применение, placeholder для импорта |
| **О приложении** | `/about` | Версия, список функций, пояснения об ограничениях платформы |

## Технологический стек

- **Kotlin** + **Jetpack Compose** (Material 3)
- **Navigation Compose** — декларативная навигация
- **DataStore Preferences** + **Gson** — хранение профилей и настроек
- **ViewModel** + **StateFlow** — архитектура MVVM
- **ActivityResultContracts** — системный файловый пикер (без лишних разрешений)
- **minSdk 26** (Android 8.0+), **targetSdk 35**

## Сборка

### Требования
- **Android Studio Ladybug** (2024.2.1) или выше
- **JDK 17**
- **Android SDK 35** + Build Tools 35

### Сборка из командной строки
```bash
# Debug APK
./gradlew assembleDebug

# Release APK (без подписи)
./gradlew assembleRelease
```

APK находится по адресу:
- Debug:   `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Сборка через Android Studio
1. `File → Open` → выбрать папку `oxide-android`
2. Дождаться синхронизации Gradle
3. `Build → Build Bundle(s) / APK(s) → Build APK(s)`

## GitHub Actions

Файл `.github/workflows/build.yml` собирает debug и release APK при каждом push в `main` и публикует их как артефакты на вкладке **Actions**.

## Известные ограничения

- **Профили** — только локальные настройки приложения. IMEI, Android ID и системные параметры устройства не изменяются.
- **Приложения** — иконки приложений отображаются как placeholder (системный `android.R.drawable.sym_def_app_icon`). Для загрузки реальных иконок используйте `PackageManager.getApplicationIcon()`.
- **Скины Premium** — заглушка, доступ в следующих версиях.
- **Импорт скинов** — интерфейс готов, логика импорта в следующей версии.
- Root-доступ, изменение HWID/IMEI, инъекции в игры **не реализованы и не планируются** — это противоречит политике безопасности Android.

## Структура проекта

```
oxide-android/
├── .github/workflows/build.yml     # CI/CD
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/oxide/launcher/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/               # ProfileRepository, SettingsRepository
│   │   │   ├── viewmodel/          # OxideViewModel
│   │   │   └── ui/
│   │   │       ├── components/     # GlassCard, OxideBackground, NeonActionCard…
│   │   │       ├── navigation/     # OxideNavGraph, Screen sealed class
│   │   │       ├── screens/        # 7 экранов
│   │   │       └── theme/          # Color, Type, Theme
│   │   └── res/
│   │       ├── drawable/           # Адаптивная иконка (SVG)
│   │       ├── mipmap-*/           # PNG иконки
│   │       └── values/             # strings, themes
│   └── build.gradle.kts
├── gradle/
│   ├── libs.versions.toml
│   └── wrapper/
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

---

**OXIDE · Твой мир в твоих руках**
